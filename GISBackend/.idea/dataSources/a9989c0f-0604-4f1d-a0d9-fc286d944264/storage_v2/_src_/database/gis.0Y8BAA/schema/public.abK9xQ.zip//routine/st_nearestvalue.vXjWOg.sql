create function st_nearestvalue(rast raster, pt geometry, exclude_nodata_value boolean DEFAULT true) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT st_nearestvalue($1, 1, $2, $3) $$;

comment on function st_nearestvalue(raster, geometry, boolean) is 'args: rast, pt, exclude_nodata_value=true - Returns the nearest non-NODATA value of a given bands pixel specified by a columnx and rowy or a geometric point expressed in the same spatial reference coordinate system as the raster.';

alter function st_nearestvalue(raster, geometry, boolean) owner to postgres;

