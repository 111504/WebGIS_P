create function st_intersection(rast raster, geomin geometry) returns SETOF geomval
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.ST_Intersection($2, $1, 1) $$;

comment on function st_intersection(raster, geometry) is 'args: rast, geom - Returns a raster or a set of geometry-pixelvalue pairs representing the shared portion of two rasters or the geometrical intersection of a vectorization of the raster and a geometry.';

alter function st_intersection(raster, geometry) owner to postgres;

