create function st_intersection(rast1 raster, rast2 raster, returnband text DEFAULT 'BOTH'::text, nodataval double precision[] DEFAULT NULL::double precision[]) returns raster
    immutable
    parallel safe
    language sql
as
$$ SELECT st_intersection($1, 1, $2, 1, $3, $4) $$;

comment on function st_intersection(raster, raster, text, double precision[]) is 'args: rast1, rast2, returnband, nodataval - Returns a raster or a set of geometry-pixelvalue pairs representing the shared portion of two rasters or the geometrical intersection of a vectorization of the raster and a geometry.';

alter function st_intersection(raster, raster, text, double precision[]) owner to postgres;

