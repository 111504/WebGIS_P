create function st_dfullywithin(rast1 raster, nband1 integer, rast2 raster, nband2 integer, distance double precision) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$ SELECT $1::public.geometry OPERATOR(public.&&) public.ST_Expand(public.ST_ConvexHull($3), $5) AND $3::geometry OPERATOR(public.&&) public.ST_Expand(public.ST_ConvexHull($1), $5) AND CASE WHEN $2 IS NULL OR $4 IS NULL THEN public._ST_DFullyWithin(public.ST_ConvexHull($1), public.ST_Convexhull($3), $5) ELSE public._ST_DFullyWithin($1, $2, $3, $4, $5) END $$;

comment on function st_dfullywithin(raster, integer, raster, integer, double precision) is 'args: rastA, nbandA, rastB, nbandB, distance_of_srid - Return true if rasters rastA and rastB are fully within the specified distance of each other.';

alter function st_dfullywithin(raster, integer, raster, integer, double precision) owner to postgres;

