create function st_asjpeg(rast raster, nband integer, options text[] DEFAULT NULL::text[]) returns bytea
    immutable
    parallel safe
    language sql
as
$$ SELECT public.st_asjpeg(st_band($1, $2), $3) $$;

comment on function st_asjpeg(raster, integer, text[]) is 'args: rast, nband, options=NULL - Return the raster tile selected bands as a single Joint Photographic Exports Group (JPEG) image (byte array). If no band is specified and 1 or more than 3 bands, then only the first band is used. If only 3 bands then all 3 bands are used and mapped to RGB.';

alter function st_asjpeg(raster, integer, text[]) owner to postgres;

