create function _st_countagg_transfn(agg agg_count, rast raster, exclude_nodata_value boolean) returns agg_count
    immutable
    parallel safe
    language plpgsql
as
$$
	DECLARE
		rtn_agg agg_count;
	BEGIN
		rtn_agg :=  public.__ST_countagg_transfn(
			agg,
			rast,
			1, exclude_nodata_value,
			1
		);
		RETURN rtn_agg;
	END;
	$$;

alter function _st_countagg_transfn(agg_count, raster, boolean) owner to postgres;

