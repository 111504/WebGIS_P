create function box3d(raster) returns box3d
    immutable
    strict
    parallel safe
    language sql
as
$$select box3d( public.ST_convexhull($1))$$;

comment on function box3d(raster) is 'args: rast - Returns the box 3d representation of the enclosing box of the raster.';

alter function box3d(raster) owner to postgres;

