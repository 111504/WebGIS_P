create function st_intersects(rast1 raster, nband1 integer, rast2 raster, nband2 integer) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$ SELECT $1 OPERATOR(public.&&) $3 AND CASE WHEN $2 IS NULL OR $4 IS NULL THEN public._st_intersects(public.st_convexhull($1), public.st_convexhull($3)) ELSE public._st_intersects($1, $2, $3, $4) END $$;

comment on function st_intersects(raster, integer, raster, integer) is 'args: rastA, nbandA, rastB, nbandB - Return true if raster rastA spatially intersects raster rastB.';

alter function st_intersects(raster, integer, raster, integer) owner to postgres;

