create function st_clip(rast raster, geom geometry, nodataval double precision[] DEFAULT NULL::double precision[], crop boolean DEFAULT true) returns raster
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_Clip($1, NULL, $2, $3, $4) $$;

comment on function st_clip(raster, geometry, double precision[], boolean) is 'args: rast, geom, nodataval=NULL, crop=TRUE - Returns the raster clipped by the input geometry. If band number not is specified, all bands are processed. If crop is not specified or TRUE, the output raster is cropped.';

alter function st_clip(raster, geometry, double precision[], boolean) owner to postgres;

