create function st_asgml(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT public._ST_AsGML(2,$1::public.geometry,15,0, NULL, NULL);  $$;

alter function st_asgml(text) owner to postgres;

