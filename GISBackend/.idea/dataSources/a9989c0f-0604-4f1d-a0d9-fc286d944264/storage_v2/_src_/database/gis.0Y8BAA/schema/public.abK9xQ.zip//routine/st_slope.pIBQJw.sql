create function st_slope(rast raster, nband integer DEFAULT 1, pixeltype text DEFAULT '32BF'::text, units text DEFAULT 'DEGREES'::text, scale double precision DEFAULT 1.0, interpolate_nodata boolean DEFAULT false) returns raster
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_slope($1, $2, NULL::public.raster, $3, $4, $5, $6) $$;

comment on function st_slope(raster, integer, text, text, double precision, boolean) is 'args: rast, nband=1, pixeltype=32BF, units=DEGREES, scale=1.0, interpolate_nodata=FALSE - Returns the slope (in degrees by default) of an elevation raster band. Useful for analyzing terrain.';

alter function st_slope(raster, integer, text, text, double precision, boolean) owner to postgres;

